package testng;

import org.testng.annotations.Test;

public class Temp {
	
	@Test
	public void Test1(){
		System.out.println("Hi");
	}

}
